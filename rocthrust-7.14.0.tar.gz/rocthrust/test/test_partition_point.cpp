/*
 *  Copyright 2008-2013 NVIDIA Corporation
 *  Modifications Copyright© 2019-2025 Advanced Micro Devices, Inc. All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

#include <thrust/functional.h>
#include <thrust/iterator/retag.h>
#include <thrust/partition.h>

#include "test_param_fixtures.hpp"
#include "test_real_assertions.hpp"
#include "test_utils.hpp"

TESTS_DEFINE(PartitionPointVectorTests, VectorSignedIntegerTestsParams);

template <typename T>
struct is_even
{
  THRUST_HOST_DEVICE bool operator()(T x) const
  {
    return ((int) x % 2) == 0;
  }
};

TYPED_TEST(PartitionPointVectorTests, TestPartitionPointSimple)
{
  using Vector   = typename TestFixture::input_type;
  using Iterator = typename Vector::iterator;

  SCOPED_TRACE(testing::Message() << "with device_id= " << test::set_device_from_ctest());

  Vector v{1, 1, 1, 0};

  Iterator first = v.begin();

  Iterator last = v.begin() + 4;
  Iterator ref  = first + 3;
  ASSERT_EQ_QUIET(ref, thrust::partition_point(first, last, ::internal::identity{}));

  last = v.begin() + 3;
  ref  = last;
  ASSERT_EQ_QUIET(ref, thrust::partition_point(first, last, ::internal::identity{}));
}

TYPED_TEST(PartitionPointVectorTests, TestPartitionPoint)
{
  using Vector   = typename TestFixture::input_type;
  using T        = typename Vector::value_type;
  using Iterator = typename Vector::iterator;

  SCOPED_TRACE(testing::Message() << "with device_id= " << test::set_device_from_ctest());

  const size_t n = (1 << 16) + 13;

  for (auto seed : get_seeds())
  {
    SCOPED_TRACE(testing::Message() << "with seed= " << seed);

    Vector v = get_random_data<T>(n, get_default_limits<T>::min(), get_default_limits<T>::max(), seed);

    Iterator ref = thrust::stable_partition(v.begin(), v.end(), is_even<T>());

    ASSERT_EQ(ref - v.begin(), thrust::partition_point(v.begin(), v.end(), is_even<T>()) - v.begin());
  }
}

template <typename ForwardIterator, typename Predicate>
ForwardIterator partition_point(my_system& system, ForwardIterator first, ForwardIterator, Predicate)
{
  system.validate_dispatch();
  return first;
}

TEST(PartitionPointTests, TestPartitionPointDispatchExplicit)
{
  SCOPED_TRACE(testing::Message() << "with device_id= " << test::set_device_from_ctest());

  thrust::device_vector<int> vec(1);

  my_system sys(0);
  thrust::partition_point(sys, vec.begin(), vec.begin(), 0);

  ASSERT_EQ(true, sys.is_valid());
}

template <typename ForwardIterator, typename Predicate>
ForwardIterator partition_point(my_tag, ForwardIterator first, ForwardIterator, Predicate)
{
  *first = 13;
  return first;
}

TEST(PartitionPointTests, TestPartitionPointDispatchImplicit)
{
  SCOPED_TRACE(testing::Message() << "with device_id= " << test::set_device_from_ctest());

  thrust::device_vector<int> vec(1);

  thrust::partition_point(thrust::retag<my_tag>(vec.begin()), thrust::retag<my_tag>(vec.begin()), 0);

  ASSERT_EQ(13, vec.front());
}

struct test_less_than
{
  long long expected;

  THRUST_DEVICE bool operator()(long long y)
  {
    return y < expected;
  }
};

void TestPartitionPointWithBigIndexesHelper(int magnitude)
{
  thrust::counting_iterator<long long> begin(0);
  thrust::counting_iterator<long long> end = begin + (1ll << magnitude);
  ASSERT_EQ(thrust::distance(begin, end), 1ll << magnitude);

  test_less_than fn = {(1ll << magnitude) - 17};

  ASSERT_EQ(thrust::distance(begin, thrust::partition_point(thrust::device, begin, end, fn)), (1ll << magnitude) - 17);
}

TEST(PartitionPointTests, TestPartitionPointWithBigIndexes)
{
  SCOPED_TRACE(testing::Message() << "with device_id= " << test::set_device_from_ctest());

  TestPartitionPointWithBigIndexesHelper(30);
  TestPartitionPointWithBigIndexesHelper(31);
  TestPartitionPointWithBigIndexesHelper(32);
  TestPartitionPointWithBigIndexesHelper(33);
}
